//
//  AppDelegate.h
//  SoftMeter application analytics IOS demo
//
//  Copyright © 2018 StarMessage software. All rights reserved.
//    https://www.starmessagesoftware.com/softmeter
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

