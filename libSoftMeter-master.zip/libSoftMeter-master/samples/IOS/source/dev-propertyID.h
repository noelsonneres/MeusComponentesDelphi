//
//  SoftMeter application analytics IOS demo
//
//  Copyright © 2018 StarMessage software. All rights reserved.
//    https://www.starmessagesoftware.com/softmeter
//

// private file. Do not distribute.

#define PROPERTYID_OVERRIDE

const char *gaPropertyID = "UA-385839-13";
