//
//  ViewController.h
//  SoftMeter application analytics IOS demo
//
//  Copyright © 2018 StarMessage software. All rights reserved.
//    https://www.starmessagesoftware.com/softmeter
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

