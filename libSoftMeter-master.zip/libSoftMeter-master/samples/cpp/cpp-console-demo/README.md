﻿**How to track a C/C++ software application with Google Analytics**  

- See [cpp-demo-main.cpp](cpp-demo-main.cpp)

> **SoftMeter application analytics SDK for Windows, MacOS, IOS**
>
> ![SoftMeter application analytics logo](https://www.starmessagesoftware.com/myfiles/softmeter-icon-128x155.png)  
> Listen to the heartbeat of your software
>
> For more info go to the [SoftMeter website](https://www.StarMessageSoftware.com/softmeter)
